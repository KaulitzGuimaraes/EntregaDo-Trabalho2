package k188530.ft.unicamp.br.yourrestaurantchoice.service;



import java.util.HashMap;
import java.util.Map;

public class RadioBtnTransformer {
    static private  RadioBtnTransformer radioBtnTransformer;

    private Map<String,Integer> ageT = new HashMap<>();

    private Map<String,Integer> priceT = new HashMap<>();

    private RadioBtnTransformer(){

        ageT.put("Young",1);
        ageT.put("Adult",2);
        ageT.put("Elder",3);
        priceT.put("$",1);
        priceT.put("$$",2);
        priceT.put("$$$",3);
    }

    public int getValueFromAgeTranform(String key){
        return  this.ageT.get(key);
    }

    public int getValueFromPriceTranform(String key){
        return  this.priceT.get(key);
    }

    static public RadioBtnTransformer getRadioBtnTransformer(){
        if (RadioBtnTransformer.radioBtnTransformer == null)
            RadioBtnTransformer.radioBtnTransformer = new RadioBtnTransformer();

        return RadioBtnTransformer.radioBtnTransformer;
    }

}
