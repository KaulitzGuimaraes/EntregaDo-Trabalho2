package k188530.ft.unicamp.br.yourrestaurantchoice.frames.user;

import android.content.res.AssetManager;
import android.os.Build;
import android.os.Bundle;


import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;


import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;


import k188530.ft.unicamp.br.yourrestaurantchoice.MainActivity;
import k188530.ft.unicamp.br.yourrestaurantchoice.R;
import k188530.ft.unicamp.br.yourrestaurantchoice.archive.Archive;
import k188530.ft.unicamp.br.yourrestaurantchoice.archive.Asset;
import k188530.ft.unicamp.br.yourrestaurantchoice.model.UserForm;
import k188530.ft.unicamp.br.yourrestaurantchoice.service.FormFactory;
import k188530.ft.unicamp.br.yourrestaurantchoice.service.RadioBtnTransformer;
import k188530.ft.unicamp.br.yourrestaurantchoice.service.Restaurants.Restaurants;
import k188530.ft.unicamp.br.yourrestaurantchoice.service.Restaurants.YourRestaurants;
import k188530.ft.unicamp.br.yourrestaurantchoice.service.kmeans.Ai;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * to handle interaction events.
 * create an instance of this fragment.
 */
public class UserFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private Button userButton,deleteButton;
    private RadioGroup ageRange;
    private RadioGroup pricePref;
    private EditText username;
    private EditText email;
    private CheckBox japanese;
    private CheckBox italian;
    private CheckBox fastFood;
    private CheckBox health;
    private CheckBox rock;
    private CheckBox pop;
    private CheckBox mpb;
    private CheckBox backgroundMusic;
    private FormFactory formFactory = new FormFactory();
    private  View view;
    private String dirPath;
    private   AssetManager assetManager;
    private static UserForm user;
    private UserFirebase userFirebase;
    private FirebaseDatabase firebaseDatabase;
    private DatabaseReference databaseReference;


    @RequiresApi(api = Build.VERSION_CODES.O)
    public UserFragment(String dirPath, AssetManager assetManager, DatabaseReference databaseReference, FirebaseDatabase firebaseDatabase) throws Exception {
        // Required empty public constructor
        this.dirPath = dirPath;
        this.assetManager = assetManager;
        this.databaseReference = databaseReference;
        this.firebaseDatabase = firebaseDatabase;
        this.databaseReference = FirebaseDatabase.getInstance().getReference().child("User");
    }
    @RequiresApi(api = Build.VERSION_CODES.O)
    private void databaseLoad() throws Exception {

//        Restaurants.getRestaurants().addRestaurants(this.databaseReference);
        this.databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                if (dataSnapshot.exists()) {
                    HashMap<String, Object> dataMap = (HashMap<String, Object>) dataSnapshot.getValue();

                    for (String key : dataMap.keySet()) {
                        Object data = dataMap.get(key);
                        try {

                            HashMap<String, Object> userData = (HashMap<String, Object>) data;
//                            System.out.println(userData.get("foodPreference"));

                            UserForm.setFormH(userData);
                            userLoad();


                        } catch (ClassCastException cce) {

                            try {

                                String mString = String.valueOf(dataMap.get(key));


                            } catch (Exception cce2) {

                            }
                        } catch (Exception e) {

                            e.printStackTrace();
                        }

                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }


    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        if (this.view == null)
            this.view = inflater.inflate(R.layout.fragment_user, container, false);
        this.userButton = this.view.findViewById(R.id.user_btn);
        this.deleteButton = this.view.findViewById(R.id.user_btn_delete);
        this.getUiValues();
        this.addBtnLoad();
        try {
            this.userFirebase = new  UserFirebase(databaseReference,firebaseDatabase);
            this.databaseLoad();
        } catch (Exception e) {
            e.printStackTrace();
        }



        return this.view;
    }


    @RequiresApi(api = Build.VERSION_CODES.O)
   final public void userLoad() {
//        this.archive = new Archive(this.dirPath + "/user.dat");

        this.verifyIfUserExists();

    }
    private void getUiValues() {
        this.username = this.view.findViewById(R.id.username);
        this.email = this.view.findViewById(R.id.email);
        this.ageRange = this.view.findViewById(R.id.age_opt);
        this.pricePref = this.view.findViewById(R.id.price_opt);
        this.japanese = this.view.findViewById(R.id.food_japanese);
        this.italian = this.view.findViewById(R.id.food_italian);
        this.fastFood = this.view.findViewById(R.id.food_fast);
        this.health = this.view.findViewById(R.id.health);
        this.rock = this.view.findViewById(R.id.music_rock);
        this.pop = this.view.findViewById(R.id.music_pop);
        this.mpb = this.view.findViewById(R.id.music_mpb);
        this.backgroundMusic = this.view.findViewById(R.id.music_bg);
    }
    private void uploadUserData() {
        this.formFactory.createFoodPreference(
                this.getBinaryValueFromCheckBox(this.japanese),
                this.getBinaryValueFromCheckBox(this.italian),
                this.getBinaryValueFromCheckBox(this.fastFood),
                this.getBinaryValueFromCheckBox(this.health)
        );
        this.formFactory.createMusicPreference(
                this.getBinaryValueFromCheckBox(this.rock),
                this.getBinaryValueFromCheckBox(this.pop),
                this.getBinaryValueFromCheckBox(this.mpb),
                this.getBinaryValueFromCheckBox(this.backgroundMusic)
        );
        UserForm userForm = this.formFactory.createForm(this.username.getText().toString(),
                this.getIntegerValueFromRadioBtn(this.pricePref.getCheckedRadioButtonId()),
                this.email.getText().toString(),
                this.getIntegerValueFromRadioBtn(this.ageRange.getCheckedRadioButtonId()));
        UserForm.setForm(userForm);
    }

    private int getBinaryValueFromCheckBox(CheckBox checkBox) {
        return checkBox.isChecked() ? 0 : 1;
    }

    private int getIntegerValueFromRadioBtn(int radioId) {
        RadioButton radioButton = this.view.findViewById(radioId);
        try {
            return RadioBtnTransformer.getRadioBtnTransformer().getValueFromAgeTranform(radioButton.getText().toString());
        } catch (Exception e) {
            return RadioBtnTransformer.getRadioBtnTransformer().getValueFromPriceTranform(radioButton.getText().toString());
        }

    }


    @RequiresApi(api = Build.VERSION_CODES.O)
    final private void verifyIfUserExists() {
        if (UserForm.getForm() == null) {
        this.username.setEnabled(true);
        this.deleteButton.setEnabled(false);
        this.username.setText("");
        this.email.setText("");
            this.userButton.setText("SUBMIT");

        }
        if (UserForm.getForm() != null) {
            this.username.setText(UserForm.getForm().getUsername());
            this.email.setText(UserForm.getForm().getEmail());
            this.username.setEnabled(false);
            this.deleteButton.setEnabled(true);
            this.userFirebase.addOrUploadUser();
            this.userButton.setText("UPDATE");

        }

    }

    private void addBtnLoad(){
        Button btn = view.findViewById(R.id.user_btn);
        Button btn2 = view.findViewById(R.id.user_btn_delete);
        btn.setOnClickListener(
                new View.OnClickListener(){
                    @RequiresApi(api = Build.VERSION_CODES.O)
                    public void onClick(View view){
                        try {
                            UserFragment.this.addUser(UserFragment.this.view);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                    }
                } );
        btn2.setOnClickListener(
                new View.OnClickListener(){
                    @RequiresApi(api = Build.VERSION_CODES.O)
                    public void onClick(View view){
                        try {
                            UserFragment.this.deleteUser(UserFragment.this.view);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }
                } );
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void addUser(View view) throws IOException {
        this.uploadUserData();
        if (this.userButton.getText().toString().equalsIgnoreCase("submit"))
              this.userFirebase.addOrUploadUser();
        this.verifyIfUserExists();
        getRestaurantNames();
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void getRestaurantNames() {
        try {

            InputStream io = this.assetManager.open("restaurants.csv");
            String fileName = dirPath + "/restaurants.csv";
            String userData = UserForm.getForm().toString();
            Asset asset = new Asset(io, fileName, userData);
            Ai ai = new Ai(UserForm.getForm().getUsername());
            ArrayList<String> arrayList = ai.getRecomendedRestaurantsNames(asset.getFile());
            MainActivity.setRestaurantArray(new YourRestaurants(arrayList.toArray()));
            Toast.makeText( getContext(),"Restaurants List has been updated with success !!",Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public void deleteUser(View view){
        this.userFirebase.deletedUser();
        UserForm.setForm(null);
        this.verifyIfUserExists();
        Toast.makeText( getContext(),"User deleted with sucess!!!",Toast.LENGTH_SHORT).show();
    }

}


