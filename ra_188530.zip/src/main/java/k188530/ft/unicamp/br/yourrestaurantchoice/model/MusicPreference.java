package k188530.ft.unicamp.br.yourrestaurantchoice.model;

import java.io.Serializable;

public class MusicPreference  implements Serializable {
    private int rock;
    private int pop;
    private int mpb;
    private int backgroundMusic;

    public MusicPreference(int rock, int pop, int mpb, int backgroundMusic) {
        this.rock = rock;
        this.pop = pop;
        this.mpb = mpb;
        this.backgroundMusic = backgroundMusic;
    }

    public int getRock() {
        return rock;
    }

    public void setRock(int rock) {
        this.rock = rock;
    }

    public int getPop() {
        return pop;
    }

    public void setPop(int pop) {
        this.pop = pop;
    }

    public int getMpb() {
        return mpb;
    }

    public void setMpb(int mpb) {
        this.mpb = mpb;
    }

    public int getBackgroundMusic() {
        return backgroundMusic;
    }

    public void setBackgroundMusic(int backgroundMusic) {
        this.backgroundMusic = backgroundMusic;
    }
    public String toString(){
        return  this.rock+", " + this.pop+", "+this.mpb+", " + this.backgroundMusic +", ";
    }

}
