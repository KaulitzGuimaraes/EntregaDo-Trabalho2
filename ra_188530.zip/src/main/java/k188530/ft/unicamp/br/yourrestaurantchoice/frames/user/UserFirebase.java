package k188530.ft.unicamp.br.yourrestaurantchoice.frames.user;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import k188530.ft.unicamp.br.yourrestaurantchoice.model.UserForm;

public class UserFirebase {
    private DatabaseReference databaseReference;
    private FirebaseDatabase mDatabase;

    public UserFirebase(DatabaseReference databaseReference,FirebaseDatabase firebaseDatabase) {
        this.mDatabase = firebaseDatabase;
        this.databaseReference = databaseReference;
}


    public void addOrUploadUser() {
        databaseReference.child(UserForm.getForm().getUsername()).setValue(UserForm.getForm());
    }
    public void deletedUser() {
        databaseReference.child(UserForm.getForm().getUsername()).removeValue();
    }
}
