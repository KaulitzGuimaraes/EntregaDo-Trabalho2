package k188530.ft.unicamp.br.yourrestaurantchoice;


import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

import k188530.ft.unicamp.br.yourrestaurantchoice.frames.aboutus.AboutUsFragment;
import k188530.ft.unicamp.br.yourrestaurantchoice.frames.restarants.RestaurantsFragments;
import k188530.ft.unicamp.br.yourrestaurantchoice.frames.user.UserFragment;
import k188530.ft.unicamp.br.yourrestaurantchoice.service.Restaurants.RestaurantArray;
import k188530.ft.unicamp.br.yourrestaurantchoice.service.Restaurants.Restaurants;

@RequiresApi(api = Build.VERSION_CODES.O)
public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {


    /**
     * TODO : Add restaurants array
     * TODO : Test : MysqlConn
     * TODO : Start java-ml impl
     */
    private FragmentManager fragmentManager;
    private UserFragment userFragment;
    private DatabaseReference databaseReference;
    private FirebaseDatabase mDatabase;
    static private RestaurantArray restaurantArray;


    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        navigationView.setNavigationItemSelectedListener(this);
        try {
            this.loadFragment(savedInstanceState);
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            restaurantArray = Restaurants.getRestaurants();
        } catch (Exception e) {
            e.printStackTrace();
        }
//        userLoad();
        try {
            this.databaseLoad();
        } catch (Exception e) {
            e.printStackTrace();
        }


    }


    private void loadFragment(Bundle savedInstanceState) throws Exception {
        if (savedInstanceState == null) {
            this.fragmentManager = getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            this.userFragment = new UserFragment(getFilesDir().getPath(), getAssets(),this.databaseReference,this.mDatabase);
            fragmentTransaction.add(R.id.frame, userFragment, "user_f");
            fragmentTransaction.commit();
        }
    }

    private void databaseLoad() throws Exception {
        this.mDatabase = FirebaseDatabase.getInstance();
        this.databaseReference = FirebaseDatabase.getInstance().getReference().child("Restaurants");
//        Restaurants.getRestaurants().addRestaurants(this.databaseReference);
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                if (dataSnapshot.exists()) {
                    HashMap<String, Object> dataMap = (HashMap<String, Object>) dataSnapshot.getValue();

                    for (String key : dataMap.keySet()) {

                        Object data = dataMap.get(key);

                        try {
                            HashMap<String, Object> userData = (HashMap<String, Object>) data;
                            Restaurants.getRestaurants().addRestaurant(key, userData);


                        } catch (ClassCastException cce) {

                            try {

                                String mString = String.valueOf(dataMap.get(key));


                            } catch (Exception cce2) {

                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }



    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();


        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_user) {
            this.replaceFragment(this.userFragment,"user_f");
        } else if (id == R.id.nav_restaurants) {

            RestaurantsFragments authorsFragments = new RestaurantsFragments(restaurantArray);
            this.replaceFragment(authorsFragments,"restaurants_f");

        }else if(id == R.id.nav_about_us){
           AboutUsFragment aboutUsFragment = new AboutUsFragment();
           this.replaceFragment(aboutUsFragment,"about_us_f");

        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
    private void replaceFragment(Fragment fragment, String tag){
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.frame, fragment, tag);
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
    }

   static public void setRestaurantArray(RestaurantArray restaurantArray) throws Exception {
        try {
            MainActivity.restaurantArray = restaurantArray;
        }catch (Exception e){
            MainActivity.restaurantArray = Restaurants.getRestaurants();
        }

    }

    static  public RestaurantArray getRestaurantArray() {
        return restaurantArray;
    }
}
