package k188530.ft.unicamp.br.yourrestaurantchoice.service;

import k188530.ft.unicamp.br.yourrestaurantchoice.model.FoodPreference;
import k188530.ft.unicamp.br.yourrestaurantchoice.model.MusicPreference;
import k188530.ft.unicamp.br.yourrestaurantchoice.model.RestaurantForm;
import k188530.ft.unicamp.br.yourrestaurantchoice.model.UserForm;

public class FormFactory {


    private FoodPreference foodPreference;

    private MusicPreference musicPreference;


    public  void createFoodPreference(int japanese, int italian, int fastFood, int health){
        this.foodPreference = new FoodPreference(japanese,italian,fastFood,health);
    }
    public  void createMusicPreference(int rock, int pop, int mpb, int backgroundMusic){
        this.musicPreference = new MusicPreference(rock,pop,mpb,backgroundMusic);
    }
    public UserForm createForm(String username, int pricePreference ,String email, int ageRange){
        return new UserForm(username,pricePreference,this.foodPreference,this.musicPreference,email,ageRange);
    }

    public RestaurantForm createForm(String username, int pricePreference,  String address, String briefDefinition, String website, String telephone, String photo) {
        return new RestaurantForm(username,pricePreference,this.foodPreference,this.musicPreference,address,briefDefinition,website,telephone,photo);
    }
}
