package k188530.ft.unicamp.br.yourrestaurantchoice.service.Restaurants;

import com.google.firebase.database.DatabaseReference;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

import k188530.ft.unicamp.br.yourrestaurantchoice.model.Restaurant;

public class Restaurants implements RestaurantArray{
    private static Restaurants restaurants;
    private ArrayList<Restaurant> restaurantHashMap;
    private Restaurant restaurant;

    private Restaurants() {
        restaurantHashMap = new ArrayList<>();

    }

    public void addRestaurant(String name, HashMap<String, Object> restaurant) {
        Restaurant restaurant2 = new Restaurant();
        restaurant2.setName(restaurant.get("name").toString());
        restaurant2.setDefinition(restaurant.get("definition").toString());
        restaurant2.setWebsite(restaurant.get("website").toString());
        restaurant2.setTelephone(restaurant.get("telephone").toString());
        restaurant2.setPhoto(restaurant.get("photo").toString());
        restaurant2.setAddress(restaurant.get("address").toString());
        restaurantHashMap.add(restaurant2);
    }

    public void addRestaurants(DatabaseReference databaseReference) {
        String[] nam, def, website, tell, photo, ad;
        ad = new String[]{"198 Jason Plaza Apt. 216 .South Lisaside, ND 41388", "46257 Nicholas Mill Suite 762 .Yatesburgh, MD 48391", "741 Lee Brooks Suite 356 .West Yvonne, MA 74158", "02800 Cook Run .Valerieton, ND 70577", "91786 Roy Spring .Debratown, FL 97263", "89230 Williamson Burg Apt. 961 .West Michaelbury, GA 12662", "Unit 8561 Box 7250 .DPO AA 96215", "80938 Graves Light Suite 372 .Woodardborough, MO 71013", "4703 Vickie Forge Apt. 587 .Port Nicholasport, NC 35051", "0673 Williams Flat .West Alexandrachester, AR 61860", "9973 Christopher Lodge Suite 750 .South Jesse, CO 94215", "61287 Sarah Center Apt. 044 .New Laura, KS 41597", "PSC 5923, Box 6176 .APO AA 11551", "3292 Brown Plains .Thompsontown, WY 81620", "358 Clark Crest .New Dawn, OH 71392", "PSC 2960, Box 1205 .APO AE 23730", "USCGC Johnson .FPO AA 27393", "Unit 7117 Box 9542 .DPO AA 66991", "3731 Tina Flats .New Michael, AK 01218", "36283 Anderson Curve Suite 647 .East Jessica, ID 60550", "2543 Wright Inlet .Rickyside, CA 44172", "289 Daniels Run Apt. 067 .New Sheila, UT 85968", "25998 Simmons Extension Apt. 737 .Lake Robert, UT 95628", "69785 Shaffer Mews .South Seth, UT 68059", "624 Deborah Hollow Apt. 611 .Lake Anna, MS 75854", "440 Juan Fork Suite 902 .Shepardville, CT 41749", "1359 James Fords .Yoderton, WI 82593", "495 Ashley Plaza .Santostown, MN 88447", "431 Wilson Well Suite 810 .New Steven, MT 03342", "Unit 7600 Box 3328 .DPO AA 44123", "55505 Garcia Pike Suite 792 .Brooksberg, NV 03246", "23684 David Ridge .North Michael, NJ 51597", "8499 Salinas Junctions Suite 425 .West Christopher, TX 29164", "3716 Brooke Row .Brooksfort, IN 18018", "3761 Kathleen Terrace Apt. 792 .South Davidstad, HI 43338", "3260 Bolton Run Suite 749 .Port Gabrielle, OR 97349", "989 Pena Crest Suite 915 .Port Lisa, MD 81565"};
        nam = new String[]{"TheFriendlyHook", "Sapphire", "TheVillageDream", "TheSmile", "Souls", "Blossoms", "TheCocoaCastle", "TheEmpress", "TheMomument", "TheBigCityFaire", "TheAromaFarmer", "TheLunarBadger", "TheBigAvenue", "TheRoyalWhale", "TheEmeraldFence", "TheCopperOyster", "Friends", "TheSapphireGrill", "TheHarmonicLobster", "TheMammothExhibit", "TheHarlequinDevil", "Shambles", "Vertigo", "TheMountainFusion", "Sunset", "TheEnigmaBistro", "TheCellar", "TheWarmGrove", "Curiosity", "Glasshouse", "Roadhouse", "TheAquaCottage", "TheCocoaShark", "LittlePersia", "Happening", "ThePeacock", "TheOrangeWharf"};
        def = new String[]{"Occur parent likely later manager stay. Growth pull cut crime tree. Same anything would fact machine start record.", "Western sure here where. Improve Republican drive film break.", "Citizen see similar artist sea. Play letter environmental first avoid. Either effect interest term.", "Stand most bill miss cause than teach. Remember hold mother work could room unit. New upon change yourself note.", "Walk commercial their mention remember I table book. Provide natural that instead step.\nReal bed seem tough.", "Day speak skill skill there see. Grow environmental east sea card in.\nStand fish over tax. Lay answer traditional politics law.\nRock movie color region relate alone.", "Unit build social law employee. Follow walk figure.\nHear its perhaps. Blood role poor environment above account.", "Determine hour least father edge more. Father least food good he break. Physical future standard up. Avoid of ability international specific as keep.", "Night particularly head arm thousand.\nWorld stage usually never. Inside turn employee explain.", "Score four nation support. Move join city left show itself even. Teach gas animal main administration turn give.", "Quality food thousand design image carry. Teacher moment few also own. Perhaps real economy kid factor form.\nStar city lot technology yet blood. Heart particular soon blue.", "Probably strategy able until what image me police. Figure today event mean single occur those last.", "Yeah hand reach but. Arrive back two mother such. Past nature southern doctor image.", "More man growth decade memory data nothing. Travel popular career American meet. Student us guy always yet.\nTreat save eye human good pay. Receive true determine quite that project.", "Mr avoid nice sort move others. Fish mind fire skin. Thousand church population seven military.\nQuickly alone own. Receive college others past conference. Term player until else.", "Next on trip force listen. They wear tonight. Write each participant effect work.\nEarly realize many mouth. Practice away officer body night.", "Born effort eight Mrs coach television Democrat. Statement cell memory matter start. Fill two tell.", "Career hour method choose. Become individual girl race kitchen trade answer.\nPublic reduce language quality bed sing major. Him finally reveal idea within who throughout operation.", "Interest husband appear share suggest way. Mother product body contain movement already. Child protect point top family could.", "Wrong pretty direction none. Mother far everything evening. Model else dog better budget.\nInstitution tend old too stuff. Threat military himself again research media half.", "My mention also such affect its night.\nName certain manage experience door everyone cost. Alone accept child other grow create. Rule trial region sit author visit win dream.", "Mind accept which should order quickly. Agent country through. Number short party PM.\nHelp training make. Degree his development operation commercial back big. War shake nature time.", "War simply you media team goal. Finish bring resource conference. Guy response production.\nNews that letter station. May organization take.\nMeet as too professional near somebody defense.", "Fear develop pick. Avoid have generation PM old sometimes interest art. Finish base style.\nStation expect safe. Impact authority up maintain company treatment particular.", "Once trouble feeling boy finally production answer draw. Even mind late positive news head. Today election necessary current your.", "Themselves authority why hope career ahead. Through left it civil truth financial west.\nEnough risk difference build result. Wind deep firm clear whole.", "Activity often plant detail wish. Watch wall defense hour teach name three. Ask catch impact carry something member best.\nView general raise there for use. Much foreign feel in.", "Left present argue collection oil fall choose.\nRegion hot impact clearly management likely. Republican he these politics of. Wrong success truth property.", "National around government song professor theory. Win coach professional worker including box sport else. Research do director mission push security foot.", "Performance analysis future former half surface floor.\nEnergy election course. Wife store keep property decision back. Without item attack send six. Ball particularly soon card hold ago look.", "Magazine born rest cold administration daughter maybe. Character tell few decade television join official. Ok successful others tree mission that issue allow.", "Everybody already more specific star back. Body rich on too. Always without accept dog anything growth TV.\nCitizen only push tax. Science team agree section. Base possible sea sort.", "Upon have company determine pretty agree hotel. Fight cup current without night.", "Their especially thus light send guess understand. Order they song budget sit black mind. Step go our training of generation government.\nSafe sister each local beautiful. Poor usually door.", "Development much onto do.\nLikely president population personal research. Life huge leg recent appear special. Himself one responsibility season national those lead.", "Mother black treatment low seat herself. Avoid face operation cold particularly.\nContinue boy interesting respond evidence environment. Sport born old.", "Any TV red. Condition defense authority back certainly choose part again.\nTell simple coach position upon now. Develop wonder painting old never career value."};
        website = new String[]{"http://wwww.thefriendlyhook.com", "http://wwww.sapphire.com", "http://wwww.thevillagedream.com", "http://wwww.thesmile.com", "http://wwww.souls.com", "http://wwww.blossoms.com", "http://wwww.thecocoacastle.com", "http://wwww.theempress.com", "http://wwww.themomument.com", "http://wwww.thebigcityfaire.com", "http://wwww.thearomafarmer.com", "http://wwww.thelunarbadger.com", "http://wwww.thebigavenue.com", "http://wwww.theroyalwhale.com", "http://wwww.theemeraldfence.com", "http://wwww.thecopperoyster.com", "http://wwww.friends.com", "http://wwww.thesapphiregrill.com", "http://wwww.theharmoniclobster.com", "http://wwww.themammothexhibit.com", "http://wwww.theharlequindevil.com", "http://wwww.shambles.com", "http://wwww.vertigo.com", "http://wwww.themountainfusion.com", "http://wwww.sunset.com", "http://wwww.theenigmabistro.com", "http://wwww.thecellar.com", "http://wwww.thewarmgrove.com", "http://wwww.curiosity.com", "http://wwww.glasshouse.com", "http://wwww.roadhouse.com", "http://wwww.theaquacottage.com", "http://wwww.thecocoashark.com", "http://wwww.littlepersia.com", "http://wwww.happening.com", "http://wwww.thepeacock.com", "http://wwww.theorangewharf.com"};
        tell = new String[]{"576-076-0592", "905-026-1613", "285-170-3095", "611-013-7100", "740-224-1394", "589-516-0907", "985-585-9896", "563-508-2455", "560-446-9953", "466-886-2728", "461-526-4051", "962-047-7219", "951-675-2507", "453-545-9966", "396-762-7627", "785-755-7069", "550-861-6195", "737-772-0823", "678-326-1065", "427-624-7494", "713-663-7894", "588-860-9305", "526-805-2051", "640-837-2150", "170-832-7882", "355-800-9741", "323-024-6396", "688-180-7612", "703-075-2070", "411-486-2187", "926-114-4404", "492-073-2625", "186-067-4553", "424-382-4793", "160-184-4285", "175-504-0198", "452-836-7860"};
        photo = new String[]{"https://www.ediblebrooklyn.com/wp-content/uploads/sites/2/2017/06/image2.jpg", "https://cdn.shopify.com/s/files/1/1641/2641/products/2nd_Ave_Deli_530x@2x.jpg?v=1541981414", "https://cdn.shopify.com/s/files/1/1641/2641/products/2nd_Ave_Deli_530x@2x.jpg?v=1541981414", "https://www.ediblebrooklyn.com/wp-content/uploads/sites/2/2017/06/image3.jpg", "https://media.newyorker.com/photos/591f549e94c161455cd5a5cb/master/w_1318,c_limit/Donohue_Angelica_Kitchen.jpg", "https://www.ediblebrooklyn.com/wp-content/uploads/sites/2/2017/06/image2.jpg", "https://media.newyorker.com/photos/591f549e94c161455cd5a5cb/master/w_1318,c_limit/Donohue_Angelica_Kitchen.jpg", "https://www.ediblebrooklyn.com/wp-content/uploads/sites/2/2017/06/image3.jpg", "https://www.ediblebrooklyn.com/wp-content/uploads/sites/2/2017/06/image3.jpg", "https://www.google.com/url?sa=i&rct=j&q=&esrc=s&source=images&cd=&ved=2ahUKEwiyiPiJzbDkAhVAF7kGHZGwCdEQjRx6BAgBEAQ&url=http%3A%2F%2Flinesandcolors.com%2F2019%2F03%2F27%2Fjohn-donohues-all-the-restaurants-in-new-york%2F&psig=AOvVaw1bFFwvZxSC3TdgyRyrhIaJ&ust=1567460775056266", "https://www.ediblebrooklyn.com/wp-content/uploads/sites/2/2017/06/image3.jpg", "https://www.ediblebrooklyn.com/wp-content/uploads/sites/2/2017/06/image2.jpg", "https://www.ediblebrooklyn.com/wp-content/uploads/sites/2/2017/06/image3.jpg", "https://cdn.shopify.com/s/files/1/1641/2641/products/2nd_Ave_Deli_530x@2x.jpg?v=1541981414", "https://www.ediblebrooklyn.com/wp-content/uploads/sites/2/2017/06/image3.jpg", "https://www.ediblebrooklyn.com/wp-content/uploads/sites/2/2017/06/image1.jpg", "https://media.newyorker.com/photos/591f549e94c161455cd5a5cb/master/w_1318,c_limit/Donohue_Angelica_Kitchen.jpg", "https://cdn.shopify.com/s/files/1/1641/2641/products/2nd_Ave_Deli_530x@2x.jpg?v=1541981414", "https://media.newyorker.com/photos/591f549e94c161455cd5a5cb/master/w_1318,c_limit/Donohue_Angelica_Kitchen.jpg", "https://www.ediblebrooklyn.com/wp-content/uploads/sites/2/2017/06/image3.jpg", "https://www.ediblebrooklyn.com/wp-content/uploads/sites/2/2017/06/image1.jpg", "https://www.google.com/url?sa=i&rct=j&q=&esrc=s&source=images&cd=&ved=2ahUKEwiyiPiJzbDkAhVAF7kGHZGwCdEQjRx6BAgBEAQ&url=http%3A%2F%2Flinesandcolors.com%2F2019%2F03%2F27%2Fjohn-donohues-all-the-restaurants-in-new-york%2F&psig=AOvVaw1bFFwvZxSC3TdgyRyrhIaJ&ust=1567460775056266", "https://cdn.shopify.com/s/files/1/1641/2641/products/2nd_Ave_Deli_530x@2x.jpg?v=1541981414", "https://www.ediblebrooklyn.com/wp-content/uploads/sites/2/2017/06/image3.jpg", "https://www.ediblebrooklyn.com/wp-content/uploads/sites/2/2017/06/image2.jpg", "https://media.newyorker.com/photos/591f549e94c161455cd5a5cb/master/w_1318,c_limit/Donohue_Angelica_Kitchen.jpg", "https://cdn.shopify.com/s/files/1/1641/2641/products/2nd_Ave_Deli_530x@2x.jpg?v=1541981414", "https://cdn.shopify.com/s/files/1/1641/2641/products/2nd_Ave_Deli_530x@2x.jpg?v=1541981414", "https://www.google.com/url?sa=i&rct=j&q=&esrc=s&source=images&cd=&ved=2ahUKEwiyiPiJzbDkAhVAF7kGHZGwCdEQjRx6BAgBEAQ&url=http%3A%2F%2Flinesandcolors.com%2F2019%2F03%2F27%2Fjohn-donohues-all-the-restaurants-in-new-york%2F&psig=AOvVaw1bFFwvZxSC3TdgyRyrhIaJ&ust=1567460775056266", "https://media.newyorker.com/photos/591f549e94c161455cd5a5cb/master/w_1318,c_limit/Donohue_Angelica_Kitchen.jpg", "https://media.newyorker.com/photos/591f549e94c161455cd5a5cb/master/w_1318,c_limit/Donohue_Angelica_Kitchen.jpg", "https://www.ediblebrooklyn.com/wp-content/uploads/sites/2/2017/06/image2.jpg", "https://www.ediblebrooklyn.com/wp-content/uploads/sites/2/2017/06/image3.jpg", "https://www.ediblebrooklyn.com/wp-content/uploads/sites/2/2017/06/image1.jpg", "https://www.google.com/url?sa=i&rct=j&q=&esrc=s&source=images&cd=&ved=2ahUKEwiyiPiJzbDkAhVAF7kGHZGwCdEQjRx6BAgBEAQ&url=http%3A%2F%2Flinesandcolors.com%2F2019%2F03%2F27%2Fjohn-donohues-all-the-restaurants-in-new-york%2F&psig=AOvVaw1bFFwvZxSC3TdgyRyrhIaJ&ust=1567460775056266", "https://www.ediblebrooklyn.com/wp-content/uploads/sites/2/2017/06/image1.jpg", "https://www.ediblebrooklyn.com/wp-content/uploads/sites/2/2017/06/image2.jpg"};
        for (int i = 0; i < nam.length; i++) {
            Restaurant restaurant = new Restaurant();
            restaurant.setPhoto(photo[i]);
            restaurant.setTelephone(tell[i]);
            restaurant.setWebsite(website[i]);
            restaurant.setDefinition(def[i]);
            restaurant.setName(nam[i]);
            restaurant.setAddress(ad[i]);
            databaseReference.child(nam[i]).setValue(restaurant);

        }


    }
    public Restaurant getRestaurant(int i) {

        return this.restaurantHashMap.get(i);


    }
    public int getRestaurantsAmount() {
        return this.restaurantHashMap.size();
    }

    public  Restaurant getRestaurant(String name){
        for (int i=0; i<this.restaurantHashMap.size();i++){
            if(this.restaurantHashMap.get(i).getName().equalsIgnoreCase(name))
                return this.restaurantHashMap.get(i);
        }
        return null;
    }

    public static Restaurants getRestaurants() throws Exception {
        try {
            if (Restaurants.restaurants == null) {
                Restaurants.restaurants = new Restaurants();
            }
            return Restaurants.restaurants;
        } catch (Exception e) {
            throw new Exception();
        }
    }

}
