package k188530.ft.unicamp.br.yourrestaurantchoice.model;

import java.io.Serializable;

abstract public class Form  implements Serializable {

    final private String username;
    private int pricePreference;
    private FoodPreference foodPreference;
    private MusicPreference musicPreference;

    public Form(String username, int pricePreference, FoodPreference foodPreference,
                MusicPreference musicPreference) {
        this.username = username;
        this.pricePreference = pricePreference;
        this.foodPreference = foodPreference;
        this.musicPreference = musicPreference;
    }


    public String getUsername() {
        return username;
    }

    public int getPricePreference() {
        return pricePreference;
    }

    public void setPricePreference(int pricePreference) {
        this.pricePreference = pricePreference;
    }

    public FoodPreference getFoodPreference() {
        return foodPreference;
    }

    public void setFoodPreference(FoodPreference foodPreference) {
        this.foodPreference = foodPreference;
    }

    public MusicPreference getMusicPreference() {
        return musicPreference;
    }

    public void setMusicPreference(MusicPreference musicPreference) {
        this.musicPreference = musicPreference;
    }

   public String toString(){
        return this.username;
   }
}
