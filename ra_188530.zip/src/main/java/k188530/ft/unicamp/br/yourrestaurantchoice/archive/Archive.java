package k188530.ft.unicamp.br.yourrestaurantchoice.archive;

import android.content.Context;
import android.os.Build;

import androidx.annotation.RequiresApi;


import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.logging.Level;
import java.util.logging.Logger;
public class Archive {
    private static final Logger LOG = Logger.getLogger(Archive.class.getName());
    private static  String SERIAL_FILENAME;
    private final Path serizableArchive;

    /**
     *
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    public Archive(String path) {
        LOG.setLevel(Level.INFO);
        SERIAL_FILENAME =  path ;
        this.serizableArchive = FileSystems.getDefault().getPath( SERIAL_FILENAME);


    }

    /**
     *
     * @param <T>
     * @param classe
     * @return
     * @throws IOException
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    public <T> T load(T classe) throws IOException {
        if (Files.exists(serizableArchive)) {
            return loadSerialized(classe);
        } else {
            return null;
        }

    }

    /**
     *
     * @param <T>
     * @param dados
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    public <T> void save(T dados) {
        try {
            ObjectOutputStream os = new ObjectOutputStream(
                    Files.newOutputStream(serizableArchive));
            os.writeObject(dados);
            System.out.println("SAVED");
            System.out.println(Files.exists(serizableArchive));
        } catch (IOException ex) {
            System.out.println("=======");
            System.out.println(ex.getMessage());
        }
    }

    /**
     *
     */
    @RequiresApi(api = Build.VERSION_CODES.O)
    public  void delete () {
        try {
            Files.delete(serizableArchive);
        } catch (IOException ex) {
            LOG.log(Level.SEVERE, "delete", ex);
        }
    }
    @RequiresApi(api = Build.VERSION_CODES.O)
    private <T> T loadSerialized(T classe) {
        ObjectInputStream fileStream;
        try {
            fileStream = new ObjectInputStream(
                    Files.newInputStream(serizableArchive));
            classe = (T) fileStream.readObject();

       } catch (ClassNotFoundException | IOException ex) {
        }
        return classe;
    }
}
