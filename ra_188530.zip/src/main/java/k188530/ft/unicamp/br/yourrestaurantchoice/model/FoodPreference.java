package k188530.ft.unicamp.br.yourrestaurantchoice.model;

import java.io.Serializable;

public class FoodPreference  implements Serializable {
    private int japanese;
    private int italian;
    private int fastFood;
    private int health;

    public FoodPreference(int japanese, int italian, int fastFood, int health) {
        this.japanese = japanese;
        this.italian = italian;
        this.fastFood = fastFood;
        this.health = health;
    }

    public int getJapanese() {
        return japanese;
    }

    public void setJapanese(int japanese) {
        this.japanese = japanese;
    }

    public int getItalian() {
        return italian;
    }

    public void setItalian(int italian) {
        this.italian = italian;
    }

    public int getFastFood() {
        return fastFood;
    }

    public void setFastFood(int fastFood) {
        this.fastFood = fastFood;
    }

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        this.health = health;
    }

    public String toString(){
        return  this.japanese+", " + this.italian+", "+this.fastFood+", " +this.health +", ";
    }
}
