package k188530.ft.unicamp.br.yourrestaurantchoice.service.kmeans;

import android.os.Build;

import androidx.annotation.RequiresApi;

import net.sf.javaml.clustering.KMeans;
import net.sf.javaml.core.Dataset;
import net.sf.javaml.tools.data.FileHandler;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

@RequiresApi(api = Build.VERSION_CODES.O)
public class Ai {
    private static final int N = 3;
    private static final int index = 10;
    private KMeans kmeans;
    private  String user;
    public Ai(String user)  {
        this.kmeans = new KMeans(Ai.N);
        this.user = user;
    }


    public Dataset[] getCluster(File f) throws IOException {
        Dataset dataset = FileHandler.loadDataset(f, Ai.index, ",");
        Dataset[] clusters = this.kmeans.cluster(dataset);
        return clusters;
    }

    private Dataset getRecomendedRestaurantsCluster(Dataset[] clusters) {
        int clusterPos = 0;
        for (int i = 0; i < clusters.length; i++) {
            for (int j = 0; j < clusters[i].size(); j++) {
                String classValue = clusters[i].get(j).classValue().toString();
                if (classValue.contains(this.user)) {
                    System.out.println(classValue);
                    clusterPos = i;
                    System.out.println("Cluster pos is : "+ clusterPos);
                   return clusters[clusterPos];
                }
            }

        }
        return clusters[clusterPos];

    }

    private ArrayList<String> getRecomendedRestaurantsNamesArray(Dataset clusters){
        ArrayList<String> restaurantNames = new ArrayList<>();
        for (int i = 0; i<clusters.size();i++){
             restaurantNames.add((clusters.get(i).classValue().toString()));
        }
        return restaurantNames;

    }
    public ArrayList<String> getRecomendedRestaurantsNames(File f) throws IOException {
        Dataset[] t = this.getCluster(f);
        Dataset cluster = this.getRecomendedRestaurantsCluster(t);
        return this.getRecomendedRestaurantsNamesArray(cluster);
    }


}
