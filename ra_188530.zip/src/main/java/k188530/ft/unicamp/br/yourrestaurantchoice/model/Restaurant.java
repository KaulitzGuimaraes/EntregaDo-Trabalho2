package k188530.ft.unicamp.br.yourrestaurantchoice.model;

public class Restaurant {
    private String address;
    private String definition;
    private String website;
    private String telephone;
    private String photo;
    private String name;

    public Restaurant(String address, String definition, String website, String telephone, String photo, String name) {
        this.address = address;
        this.definition = definition;
        this.website = website;
        this.telephone = telephone;
        this.photo = photo;
        this.name = name;
    }

    public Restaurant() {
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getDefinition() {
        return definition;
    }

    public void setDefinition(String definition) {
        this.definition = definition;
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
