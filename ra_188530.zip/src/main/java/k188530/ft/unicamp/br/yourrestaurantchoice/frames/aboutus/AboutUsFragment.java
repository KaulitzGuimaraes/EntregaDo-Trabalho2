package k188530.ft.unicamp.br.yourrestaurantchoice.frames.aboutus;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import k188530.ft.unicamp.br.yourrestaurantchoice.R;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the

 * to handle interaction events.

 * create an instance of this fragment.
 */
public class AboutUsFragment extends Fragment {
    View view;
    TextView kau,ml;
    ImageView imageView;
    String photo_url  = "https://2.bp.blogspot.com/-yo75VXeNuQE/VIJA5b_4GGI/AAAAAAACFbE/Fzr16Q8AoK0/s1600/rainbow_dash___dash_with_it_by_mysteriouskaos-d5cu0zq.png";
    public AboutUsFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_about_us, container, false);
        this.loadData();
        return view;
    }
   private void loadData(){
         kau = view.findViewById(R.id.kau_info);
         ml = view.findViewById(R.id.ml);
         imageView = view.findViewById(R.id.photo);
         Picasso.with(view.getContext()).load(photo_url).into(this.imageView);
         kau.setText("Name : Kaulitz Guimaraes Oliveira \n\nGithub : KaulitzGuimaraes\n\n");
         ml.setText("MACHINE LEARNING RULES !!!!!!");

   }





}
