package k188530.ft.unicamp.br.yourrestaurantchoice.service.Restaurants;

import k188530.ft.unicamp.br.yourrestaurantchoice.model.Restaurant;

public interface RestaurantArray {
     Restaurant getRestaurant(int i);
     int getRestaurantsAmount();
}
