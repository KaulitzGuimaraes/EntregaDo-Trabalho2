package k188530.ft.unicamp.br.yourrestaurantchoice.model;

public class RestaurantForm  extends Form{
    private String address;
    private String briefDefinition;
    private String website;
    private  String telephone;
    private  String photo;

    public RestaurantForm(String username, int pricePreference, FoodPreference foodPreference, MusicPreference musicPreference, String adress, String briefDefinition, String website, String telephone, String photo) {
        super(username, pricePreference, foodPreference, musicPreference);
        this.address = adress;
        this.briefDefinition = briefDefinition;
        this.website = website;
        this.telephone = telephone;
        this.photo = photo;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getBriefDefinition() {
        return briefDefinition;
    }

    public void setBriefDefinition(String briefDefinition) {
        this.briefDefinition = briefDefinition;
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }





}
