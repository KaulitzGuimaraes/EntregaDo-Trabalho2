package k188530.ft.unicamp.br.yourrestaurantchoice.archive;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;

public class Asset {
    InputStream io;
    String fileName;
    public Asset(InputStream io, String fileName,String userData) throws IOException {
        this.io = io;
        this.fileName = fileName;
        int size = io.available();
        String csv = geFileContent(io, size);
        csv = addUserRow(userData,csv);
        writeFileInTheInternalStorage(fileName, csv);
    }

    private void writeFileInTheInternalStorage(String fileName, String csv) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, false));
        writer.write(csv);
        writer.close();
    }

    private String geFileContent(InputStream io, int size) throws IOException {
        byte[] buffer = getBytesFromAssetFile(io, size);
        return new String(buffer);
    }
    private String addUserRow(String userData,String fileContent){
        return fileContent + userData;
    }

    private byte[] getBytesFromAssetFile(InputStream io, int size) throws IOException {
        byte[] buffer = new byte[size];
        io.read(buffer);
        io.close();
        return buffer;
    }
    public  File getFile(){
        File file = new File(this.fileName);
        return file;
    }

}
