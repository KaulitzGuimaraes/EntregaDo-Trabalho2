package k188530.ft.unicamp.br.yourrestaurantchoice.frames.restarants;


import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


import k188530.ft.unicamp.br.yourrestaurantchoice.R;
import k188530.ft.unicamp.br.yourrestaurantchoice.service.Restaurants.RestaurantArray;


public class RestaurantsFragments extends Fragment {
    private View view;
    private RecyclerView recyclerView;
    private RestaurantAdapter restaurantAdapter;
    private RestaurantArray restaurantArray;

    public RestaurantsFragments(RestaurantArray restaurantArray) {
        this.restaurantArray = restaurantArray;
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        if (this.view == null)
            this.view = inflater.inflate(R.layout.fragment_restaurants_fragments, container, false);
        this.recyclerView = view.findViewById(R.id.restaurants_rec);
        this.recyclerView.setLayoutManager(new GridLayoutManager(getActivity(),1));
        this.restaurantAdapter = new RestaurantAdapter(this.restaurantArray);
        this.recyclerView.setAdapter(this.restaurantAdapter);


//        try {
//            String imageUri = Restaurants.getRestaurants().getRestaurant("TheMomument").getPhoto();
//            Picasso.with(this.view.getContext()).load(imageUri).into(imageView);
//            Toast.makeText(view.getContext(), Restaurants.getRestaurants().getRestaurant("TheMomument").getDefinition(),Toast.LENGTH_SHORT).show();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }

        return this.view;
    }


}
