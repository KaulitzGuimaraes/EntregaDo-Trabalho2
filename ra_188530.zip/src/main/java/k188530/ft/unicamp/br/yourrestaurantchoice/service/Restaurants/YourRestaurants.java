package k188530.ft.unicamp.br.yourrestaurantchoice.service.Restaurants;

import java.util.ArrayList;

import k188530.ft.unicamp.br.yourrestaurantchoice.model.Restaurant;

public class YourRestaurants implements RestaurantArray {

    private ArrayList<Restaurant> arrayList;

    public YourRestaurants(Object[] restaurants) {
        this.arrayList = new ArrayList<>();
        this.saveRestaurantsInAArray(restaurants);

    }
    private void saveRestaurantsInAArray(Object[] restaurants){
        for(int i=0; i < restaurants.length;i++){
            try {
                Restaurant restaurant = Restaurants.getRestaurants().getRestaurant(restaurants[i].toString());
                if (restaurant != null)
                    this.arrayList.add(restaurant);
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }

    @Override
    public Restaurant getRestaurant(int i) {
        return this.arrayList.get(i);
    }

    @Override
    public int getRestaurantsAmount() {
        return  this.arrayList.size();
    }
}
