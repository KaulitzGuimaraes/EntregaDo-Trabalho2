package k188530.ft.unicamp.br.yourrestaurantchoice.model;

import java.util.HashMap;

public class UserForm  extends Form{

    private String email;
    private int ageRange;
    private static UserForm form;

    public UserForm(String username, int pricePreference, FoodPreference foodPreference, MusicPreference musicPreference, String email, int ageRange) {
        super(username, pricePreference, foodPreference, musicPreference);
        this.email = email;
        this.ageRange = ageRange;
    }


    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getAgeRange() {
        return ageRange;
    }

    public void setAgeRange(int ageRange) {
        this.ageRange = ageRange;
    }

    public  static UserForm getForm() {
        return UserForm.form;
    }
    public  static void setForm(UserForm form) {
        UserForm.form = form;
    }
    public  static void setFormH(HashMap<String,Object> form) {
        UserForm.form = new UserForm((String)form.get("username"),
                0,
                new FoodPreference(0,0,0,0),
                new MusicPreference(0,0,0,0),
                (String)form.get("email"),
                0
                );

    }
    public  String toString(){
        String userPref = "\n";
        userPref += getPricePreference();
        userPref += ", ";
        userPref += getAgeRange();
        userPref += ", ";
        userPref += getFoodPreference();
        userPref += getMusicPreference();
        userPref += getUsername();
        userPref += "\n";
        return userPref;
    }


}
