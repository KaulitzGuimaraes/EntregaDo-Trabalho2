package k188530.ft.unicamp.br.yourrestaurantchoice.frames.restarants;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;


import k188530.ft.unicamp.br.yourrestaurantchoice.R;
import k188530.ft.unicamp.br.yourrestaurantchoice.model.Restaurant;
import k188530.ft.unicamp.br.yourrestaurantchoice.service.Restaurants.RestaurantArray;

public class RestaurantAdapter extends RecyclerView.Adapter  {
    private  RestaurantArray restaurantArray;
   public RestaurantAdapter(RestaurantArray restaurantArray){
       this.restaurantArray = restaurantArray;
   }


    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.restaurant_adapter_2, parent, false);
        return new RestaurantHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        try {
            ((RestaurantHolder) holder).onBind(this.restaurantArray.getRestaurant(position));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        try {
            return this.restaurantArray.getRestaurantsAmount();
        } catch (Exception e) {
            return 0;
        }
    }
}

class RestaurantHolder extends RecyclerView.ViewHolder {
    private ImageView photo;
    private TextView name, desc,website, tellphone,address;

    public RestaurantHolder(@NonNull View itemView) {
        super(itemView);
        this.loadData(itemView);

    }

    private void loadData(View view) {
        this.name = view.findViewById(R.id.name);
        this.desc = view.findViewById(R.id.desc);
        this.photo = view.findViewById(R.id.photo);
        this.website = view.findViewById(R.id.website);
        this.tellphone = view.findViewById(R.id.tellphone);
        this.address = view.findViewById(R.id.address);

    }

    public void onBind(Restaurant restaurant) {
        this.name.setText(restaurant.getName());
        Picasso.with(itemView.getContext()).load(restaurant.getPhoto()).into(this.photo);
        this.desc.setText(restaurant.getDefinition());
        this.website.setText(restaurant.getWebsite());
        this.tellphone.setText(restaurant.getTelephone());
        this.address.setText(restaurant.getAddress());



    }
}